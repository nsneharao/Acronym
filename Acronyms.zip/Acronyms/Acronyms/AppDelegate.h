//
//  AppDelegate.h
//  Acronyms
//
//  Created by Sneha Rao on 04/20/17.
//  Copyright © 2017 Sneha Rao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

